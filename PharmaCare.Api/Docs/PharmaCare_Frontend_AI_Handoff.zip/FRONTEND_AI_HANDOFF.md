# PharmaCare — Frontend AI Handoff

## Mục tiêu

Xây frontend dựa đúng trên backend ASP.NET Core hiện có. Không tự suy đoán route,
DTO, permission hoặc trạng thái nghiệp vụ.

## Trình tự đọc bắt buộc

1. `README.md`, `Program.cs`, `appsettings.json`.
2. `Authorization/PermissionCodes.cs`.
3. Toàn bộ `Controllers/*.cs` để lập danh mục API.
4. Toàn bộ `Dtos/**/*.cs` để tạo TypeScript types.
5. `Data/DbInitializer.cs` để hiểu role–permission mặc định.
6. `Entities/*.cs` để hiểu trạng thái và quan hệ.
7. `Services/*.cs` để hiểu business rule và lỗi 409.
8. `Data/AppDbContext.cs` để hiểu constraint, FK và concurrency.

## Quy tắc tuyệt đối

- Route và HTTP method chỉ lấy từ Controllers.
- Request/response chỉ lấy từ DTOs.
- Permission chỉ lấy từ `PermissionCodes` và `DbInitializer`.
- Không tự tạo `/api/cart`, `/api/checkout`, `/api/profile` hay API khác.
- Cart giữ ở frontend; checkout dùng `POST /api/orders`.
- FEFO, giữ tồn, tính VAT/voucher và kiểm Rx do backend xử lý.
- Xử lý riêng 400, 401, 403, 404, 409.
- JWT gửi bằng `Authorization: Bearer`.
- Implement refresh rotation; refresh lỗi thì xóa phiên và về login.
- Menu và nút theo permission claim; vẫn xử lý 403 từ server.
- Không hard-code UUID, token, branch hoặc permission.
- Không commit `.env` hay secret.

## Vai trò

- `Customer`: catalog, prescription, checkout, order của chính mình.
- `Pharmacist`: xem tồn, review prescription, xử lý order/payment theo branch.
- `WarehouseStaff`: catalog, batch, receive/adjust/transfer inventory.
- `BranchManager`: kho, order, voucher, report theo branch; không review Rx mặc định.
- `Admin`: toàn bộ permission và phạm vi toàn hệ thống.

## Business rules phải phản ánh trên UI

- Thuốc Rx cần prescription `APPROVED` đúng customer, branch, product và quantity.
- Tạo order tăng reserved; cancel release; complete trừ reserved và on-hand.
- Order: `PENDING → CONFIRMED → COMPLETED` hoặc `CANCELLED`.
- VIETQR phải `PAID` trước khi complete.
- Voucher có validity, assignment, min amount, cap và usage limits.
- Customer không được confirm/complete order.
- Nhân viên chỉ truy cập branch được phân công.
- 401 = chưa xác thực; 403 = thiếu quyền; 409 = xung đột nghiệp vụ/concurrency.

## Việc phải làm trước khi xây UI

Tạo và trình bày để review:

1. `docs/backend-api-inventory.md`: method, route, permission, query, request,
   response, status code cho mọi endpoint.
2. `src/types/api.ts`: TypeScript types khớp DTO.
3. `src/api/httpClient.ts`: Bearer token, refresh queue, error normalization.
4. `src/auth`: auth store, permission guard, protected route.
5. Danh sách màn hình và mapping màn hình → API → permission.

Chỉ bắt đầu component/page sau khi hoàn thành năm đầu ra trên.

## Kiến trúc frontend đề xuất

```text
frontend-customer/   # website mua thuốc
frontend-admin/      # dược sĩ, kho, quản lý, Admin
```

Mỗi ứng dụng có `src/api`, `src/types`, `src/auth`, `src/modules`, `src/routes`
và `.env.example` riêng.

Backend hiện chưa cấu hình CORS. Khi phát triển bằng Vite, dùng dev proxy `/api`
đến URL backend; production ưu tiên reverse proxy cùng origin.

## Câu hỏi kiểm tra hiểu dự án

AI phải trả lời đúng trước khi code:

1. Tạo order qua endpoint nào? — `POST /api/orders`.
2. Cart ở đâu? — Frontend state, backend chưa có Cart.
3. Ai xử lý FEFO? — Backend.
4. Tạo order có trừ on-hand ngay không? — Không, chỉ reserve.
5. BranchManager có review Rx mặc định không? — Không.
6. Customer có confirm order không? — Không.
7. Complete VIETQR cần gì? — Payment status `PAID`.
8. 401/403/409 khác nhau thế nào? — Xác thực/quyền/xung đột nghiệp vụ.

## Tài liệu bổ sung trong gói

- `Docs/PharmaCare_Ho_so_Phan_tich_Thiet_ke_HTTT.docx`: hồ sơ phân tích đầy đủ.
- `PharmaCare.Api.http`: HTTP request mẫu hiện có.
- Swagger được bật tại `/swagger` khi backend chạy.
